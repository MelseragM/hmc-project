import * as fs from 'fs';

/**
 * Typed configuration factory consumed via `ConfigService`.
 * Grouped into namespaces (app, oracle, auth, cerner).
 */
export interface AppConfig {
  nodeEnv: string;
  port: number;
  apiPrefix: string;
  corsOrigins: string[];
  gatewayBaseUrl: string;
  requestTimeoutMs: number;
  /**
   * Per-sub-read deadline (ms) for endpoints that fan out several Oracle reads
   * in parallel (e.g. leave defaults). Kept well under `requestTimeoutMs` so one
   * slow view degrades to a partial result instead of a whole-request timeout.
   */
  aggregateReadTimeoutMs: number;
  lovCacheTtlMs: number;
  logLevel: string;
  /** Corporate-directory provider for the auth journey: LDAPS or Entra ID (Graph). */
  directory: 'ldap' | 'entra';
}

export interface OracleConfig {
  user: string;
  password: string;
  dsn: string;
  poolMin: number;
  poolMax: number;
  poolTimeout: number;
  queueTimeout: number;
  callTimeout: number;
  disabled: boolean;
  /** Use node-oracledb Thick mode (requires Oracle Client libraries at runtime). */
  thickMode: boolean;
  /** Optional path to the Oracle Client / Instant Client libraries for Thick mode. */
  libDir?: string;
}

export interface AuthConfig {
  jwtSecret: string;
  jwtIssuer: string;
  jwtAudience: string;
  jwtExpiresIn: string;
  disabled: boolean;
}

export interface CernerConfig {
  baseUrl: string;
  timeoutMs: number;
}

/** App-launch health check (API-1): downtime window + forced/optional update. */
export interface AppLaunchConfig {
  minSupportedVersion: string;
  latestVersion: string;
  downtime: boolean;
  downtimeStart: string;
  downtimeEnd: string;
}

export interface MpinConfig {
  minLength: number;
  maxLength: number;
  maxAttempts: number;
  lockoutMinutes: number;
}

export interface OtpConfig {
  length: number;
  ttlSeconds: number;
  maxAttempts: number;
  resendWindowSeconds: number;
}

export interface LdapConfig {
  enabled: boolean;
  /** Directory host, e.g. HMC.ORG.QA. */
  host: string;
  /** Directory port (636 = LDAPS, 389 = plain LDAP). */
  port: number;
  /** Use LDAPS (SSL) — true for port 636. */
  useSsl: boolean;
  /** Connection URL; derived from host/port/useSsl when LDAP_URL is unset. */
  url: string;
  /**
   * UPN domain suffix for direct binds (`username@upnDomain`), e.g. HMC.ORG.QA.
   * Defaults to `host`. Used by `authenticate()`, which binds directly as the
   * user — no service-account search needed.
   */
  upnDomain: string;
  /** Search base, e.g. DC=hmc,DC=org,DC=qa. Used by `validate()` only. */
  baseDn: string;
  /** User search filter; `{username}` is substituted at runtime. Used by `validate()` only. */
  searchFilter: string;
  /** Attribute holding the login name (e.g. sAMAccountName). Used by `validate()` only. */
  usernameAttribute: string;
  /** Service account DN used to bind before searching. Used by `validate()` only. */
  bindDn: string;
  /** Service account password. Used by `validate()` only. */
  bindPassword: string;
  /** Reject invalid/self-signed TLS certs (set true in production). */
  tlsRejectUnauthorized: boolean;
  /**
   * CA certificate(s) (PEM) to trust for LDAPS, read once at boot from
   * LDAP_CA_CERT (inline PEM) or LDAP_CA_CERT_PATH (file path) — inline wins
   * if both are set. Required to set `tlsRejectUnauthorized: true` against an
   * internal/self-signed AD CA; leave unset only for a quick connectivity
   * test (with tlsRejectUnauthorized=false).
   */
  caCert?: Buffer;
  /** Bind/search timeout in milliseconds. */
  timeoutMs: number;
}

/**
 * Azure Entra ID (Microsoft Graph) directory lookup — the cloud replacement for
 * the LDAPS `validate()` path. App-only (client-credentials) auth; used only to
 * resolve employee identity + phone (the mobile journey stays OTP + MPIN).
 */
export interface EntraConfig {
  tenantId: string;
  clientId: string;
  clientSecret: string;
  /** Graph API base, e.g. https://graph.microsoft.com/v1.0. */
  graphBaseUrl: string;
  /** AAD login base for the token endpoint, e.g. https://login.microsoftonline.com. */
  loginBaseUrl: string;
  /** User property the mobile `username` maps to (default userPrincipalName). */
  lookupAttribute: string;
  /** Token + Graph request timeout in milliseconds. */
  timeoutMs: number;
}

export interface RootConfig {
  app: AppConfig;
  oracle: OracleConfig;
  auth: AuthConfig;
  cerner: CernerConfig;
  appLaunch: AppLaunchConfig;
  mpin: MpinConfig;
  otp: OtpConfig;
  ldap: LdapConfig;
  entra: EntraConfig;
}

const toBool = (v: unknown): boolean => v === true || v === 'true';

/**
 * Resolve the LDAPS CA certificate: an inline PEM (LDAP_CA_CERT, `\n`
 * unescaped so it can be set as a single-line env var) wins over a file path
 * (LDAP_CA_CERT_PATH). Runs once at config-load time (before the Nest Logger
 * exists), so a missing/unreadable file is only ever `console.warn`'d —
 * never throws, since LDAP may be disabled or mid-provisioning.
 */
function loadLdapCaCert(): Buffer | undefined {
  const inline = process.env.LDAP_CA_CERT;
  if (inline) return Buffer.from(inline.replace(/\\n/g, '\n'), 'utf8');
  const path = process.env.LDAP_CA_CERT_PATH;
  if (!path) return undefined;
  try {
    return fs.readFileSync(path);
  } catch (err) {
    console.warn(
      `[configuration] Could not read LDAP_CA_CERT_PATH="${path}": ${(err as Error).message}`,
    );
    return undefined;
  }
}

export default (): RootConfig => ({
  app: {
    nodeEnv: process.env.NODE_ENV ?? 'development',
    port: Number(process.env.PORT ?? 3000),
    apiPrefix: process.env.API_PREFIX ?? 'api/v1',
    corsOrigins: (process.env.CORS_ORIGINS ?? '*').split(',').map((s) => s.trim()),
    gatewayBaseUrl:
      process.env.SANAAD_GATEWAY_BASE_URL ?? 'https://apigwuat.api.hamad.qa/sanaad',
    requestTimeoutMs: Number(process.env.REQUEST_TIMEOUT_MS ?? 30000),
    // Set directly for now (not env-driven). Kept under `requestTimeoutMs`.
    aggregateReadTimeoutMs: 20000,
    lovCacheTtlMs: Number(process.env.LOV_CACHE_TTL_MS ?? 300000),
    logLevel: process.env.LOG_LEVEL ?? 'debug',
    directory: process.env.AUTH_DIRECTORY === 'entra' ? 'entra' : 'ldap',
  },
  oracle: {
    user: process.env.ORACLE_USER ?? '',
    password: process.env.ORACLE_PASSWORD ?? '',
    dsn: process.env.ORACLE_DSN ?? '',
    poolMin: Number(process.env.ORACLE_POOL_MIN ?? 2),
    poolMax: Number(process.env.ORACLE_POOL_MAX ?? 10),
    poolTimeout: Number(process.env.ORACLE_POOL_TIMEOUT ?? 60),
    queueTimeout: Number(process.env.ORACLE_QUEUE_TIMEOUT_MS ?? 25000),
    callTimeout: Number(process.env.ORACLE_CALL_TIMEOUT_MS ?? 25000),
    disabled: toBool(process.env.ORACLE_DISABLED),
    thickMode: toBool(process.env.ORACLE_THICK_MODE ?? 'true'),
    libDir: process.env.ORACLE_CLIENT_LIB_DIR || undefined,
  },
  auth: {
    jwtSecret: process.env.JWT_SECRET ?? 'dev-only-secret-change-me',
    jwtIssuer: process.env.JWT_ISSUER ?? 'sanaad',
    jwtAudience: process.env.JWT_AUDIENCE ?? 'sanaad-b2e',
    jwtExpiresIn: process.env.JWT_EXPIRES_IN ?? '1h',
    disabled: toBool(process.env.AUTH_DISABLED),
  },
  cerner: {
    baseUrl: process.env.CERNER_BASE_URL ?? '',
    timeoutMs: Number(process.env.CERNER_TIMEOUT_MS ?? 10000),
  },
  appLaunch: {
    minSupportedVersion: process.env.APP_MIN_SUPPORTED_VERSION ?? '1.0.0',
    latestVersion: process.env.APP_LATEST_VERSION ?? '1.0.0',
    downtime: toBool(process.env.APP_DOWNTIME),
    downtimeStart: process.env.APP_DOWNTIME_START ?? '',
    downtimeEnd: process.env.APP_DOWNTIME_END ?? '',
  },
  mpin: {
    minLength: Number(process.env.MPIN_MIN_LENGTH ?? 4),
    maxLength: Number(process.env.MPIN_MAX_LENGTH ?? 6),
    maxAttempts: Number(process.env.MPIN_MAX_ATTEMPTS ?? 5),
    lockoutMinutes: Number(process.env.MPIN_LOCKOUT_MINUTES ?? 15),
  },
  otp: {
    length: Number(process.env.OTP_LENGTH ?? 6),
    ttlSeconds: Number(process.env.OTP_TTL_SECONDS ?? 300),
    maxAttempts: Number(process.env.OTP_MAX_ATTEMPTS ?? 5),
    resendWindowSeconds: Number(process.env.OTP_RESEND_WINDOW_SECONDS ?? 60),
  },
  ldap: {
    enabled: toBool(process.env.LDAP_ENABLED),
    host: process.env.LDAP_HOST ?? 'HMC.ORG.QA',
    port: Number(process.env.LDAP_PORT ?? 636),
    useSsl: toBool(process.env.LDAP_USE_SSL ?? 'true'),
    // Use the explicit URL when provided; an empty/unset value derives it from
    // host/port/ssl (matters in Docker where LDAP_URL is passed as "" by default).
    url:
      process.env.LDAP_URL ||
      `${toBool(process.env.LDAP_USE_SSL ?? 'true') ? 'ldaps' : 'ldap'}://${
        process.env.LDAP_HOST ?? 'HMC.ORG.QA'
      }:${Number(process.env.LDAP_PORT ?? 636)}`,
    // Defaults to LDAP_HOST — override only if the UPN suffix differs from
    // the directory host (uncommon).
    upnDomain: process.env.LDAP_UPN_DOMAIN || process.env.LDAP_HOST || 'HMC.ORG.QA',
    baseDn: process.env.LDAP_BASE_DN ?? 'DC=hmc,DC=org,DC=qa',
    searchFilter: process.env.LDAP_SEARCH_FILTER ?? '(sAMAccountName={username})',
    usernameAttribute: process.env.LDAP_USERNAME_ATTRIBUTE ?? 'sAMAccountName',
    bindDn: process.env.LDAP_BIND_DN ?? '',
    bindPassword: process.env.LDAP_BIND_PASSWORD ?? '',
    tlsRejectUnauthorized: toBool(process.env.LDAP_TLS_REJECT_UNAUTHORIZED ?? 'false'),
    caCert: loadLdapCaCert(),
    timeoutMs: Number(process.env.LDAP_TIMEOUT_MS ?? 10000),
  },
  entra: {
    tenantId: process.env.ENTRA_TENANT_ID ?? '',
    clientId: process.env.ENTRA_CLIENT_ID ?? '',
    clientSecret: process.env.ENTRA_CLIENT_SECRET ?? '',
    graphBaseUrl: process.env.ENTRA_GRAPH_BASE_URL ?? 'https://graph.microsoft.com/v1.0',
    loginBaseUrl: process.env.ENTRA_LOGIN_BASE_URL ?? 'https://login.microsoftonline.com',
    lookupAttribute: process.env.ENTRA_LOOKUP_ATTRIBUTE ?? 'userPrincipalName',
    timeoutMs: Number(process.env.ENTRA_TIMEOUT_MS ?? 10000),
  },
});
