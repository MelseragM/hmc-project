import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsOptional, IsString } from 'class-validator';
import { LangQueryDto } from '@shared/dto/lang-query.dto';
import {
  ATTACHMENT_FIELDS,
  defineOptionalStringFields,
  RequiredString,
} from '@shared/dto/oracle-submit.dto';

/** op 64 — dependent LOV query. DEP_LOOKUP_LOV mixes several vocabularies in one view. */
export class DependentLovQueryDto extends LangQueryDto {
  @ApiPropertyOptional({
    example: 'CONTACT',
    description:
      "Optional filter on the view's grouping column (Oracle D_DATA_TYPE) — returns only the rows of that type (e.g. relationships) instead of the full mixed list.",
  })
  @IsOptional()
  @IsString()
  data_type?: string;
}

const IDENTITY_FIELDS = [
  'p_title',
  'p_middle_name',
  'p_suffix',
  'p_prefix',
  'p_email_address',
  'p_relationship_start_date',
  'p_national_identifier',
  'p_passport_number',
  'p_pp_issue_date',
  'p_pp_expiry_date',
  'p_place_of_issue',
  'p_country_of_issue',
  'p_visa_type',
  'p_visa_number',
  'p_visa_issue_date',
  'p_visa_expiry_date',
  'p_visa_validity',
  'p_id_number',
  'p_id_expiry_date',
  'p_id_issue_date',
  'p_job_as_in_qid',
  'p_type_of_sponsorship',
  'p_sponsor_contact_name',
  'p_other_sponsor',
] as const;

const ADDRESS_FIELDS = [
  'p_main_address',
  'p_primary_flag',
  'p_address_type',
  'p_country',
  'p_address_line1',
  'p_address_line2',
  'p_address_line3',
  'p_city',
  'p_town_or_city',
  'p_region_1',
  'p_region_2',
  'p_region_3',
  'p_region1',
  'p_region2',
  'p_region3',
  'p_po_box',
] as const;

/**
 * op 65 — ADD_DEPENDENT_PR. The Oracle flexfield enforces more than the DTO's
 * required fields (verified live 2026-08-23, successflag S with the pinned
 * example set): at least one attachment ("Attachement is mandatory"),
 * `p_passport_number`, `p_pp_expiry_date`, `p_country_of_issue`,
 * `p_visa_type` (op 64 VISA group: 'QID(Qatari)' | 'Residence Permit'),
 * `p_visa_validity` = Yes|No, and a UNIQUE `p_id_number` (QID — duplicates
 * return "This QID already exists."). `p_relationship` must be an op 64
 * CONTACT value ('Child', 'Spouse', ... — not "Son").
 */
export class AddDependentRequestDto {
  @RequiredString('Testchild3')
  p_first_name!: string;

  @RequiredString('Ibrahim')
  p_last_name!: string;

  @RequiredString('Child')
  p_relationship!: string;

  @RequiredString('Male')
  p_gender!: string;

  @RequiredString('20150101')
  p_date_of_birth!: string;

  @RequiredString('20260823')
  p_effective_date!: string;

  [key: string]: unknown;
}

defineOptionalStringFields(
  AddDependentRequestDto,
  [
    ...IDENTITY_FIELDS,
    'p_phone_type',
    'p_phone_number',
    'p_phone_enabled',
    ...ADDRESS_FIELDS,
    'p_employment_status',
    'p_comments',
    ...ATTACHMENT_FIELDS,
  ],
  {
    p_title: 'Mr.',
    p_relationship_start_date: '20150101',
    p_email_address: 'testchild3@example.com',
    p_passport_number: 'A7654323',
    p_pp_issue_date: '20200101',
    p_pp_expiry_date: '20300101',
    p_place_of_issue: 'Doha',
    p_country_of_issue: 'QA',
    p_visa_type: 'Residence Permit',
    p_visa_number: '123456791',
    p_visa_issue_date: '20250101',
    p_visa_expiry_date: '20270101',
    p_visa_validity: 'Yes',
    p_id_number: '31599876544',
    p_id_issue_date: '20250101',
    p_id_expiry_date: '20270101',
    p_job_as_in_qid: 'Student',
    p_type_of_sponsorship: 'Employee',
    p_sponsor_contact_name: 'Amir Ibrahim',
    p_file_name1: 'birth-certificate.pdf',
    p_attachment1: 'dGVzdCBhdHRhY2htZW50',
  },
);

/**
 * op 24 — UPDATE_DEPENDENT_PR. Verified live (2026-08-23): like the add, the
 * procedure REQUIRES at least one attachment ("Attachement is mandatory").
 * The caller's dependent ids are visible in GET /profile
 * (dependentPhones/dependentAddresses).
 */
export class UpdateDependentRequestDto {
  @RequiredString('4668195')
  p_dependent_id!: string;

  [key: string]: unknown;
}

defineOptionalStringFields(
  UpdateDependentRequestDto,
  [
  'p_title',
  'p_first_name',
  'p_middle_name',
  'p_last_name',
  'p_suffix',
  'p_prefix',
  'p_email_address',
  'p_relationship',
  'p_relation_ship',
  'p_relationship_start_date',
  'p_relation_ship_start_date',
  'p_passport_number',
  'p_date_of_issue',
  'p_date_of_expire',
  'p_place_of_issue',
  'p_country_of_issue',
  'p_visa_type',
  'p_visa_number',
  'p_date_of_issue_visa',
  'p_date_of_expire_visa',
  'p_visa_validity',
  'p_visa_validy',
  'p_id_number',
  'p_expiry_date',
  'p_date_of_issue_qid',
  'p_date_of_issuue_qid',
  'p_type_of_sponsorship',
  'p_type_of_sponsership',
  'p_name_of_contact',
  'p_name_of_sponsor',
  'p_gender',
  'p_gendar',
  'p_qid_number',
  'p_date_of_birth',
  'p_effective_date',
  'p_address_id',
  ...ADDRESS_FIELDS,
  'p_phone_id',
  'p_phone_type',
  'p_phone_number',
  'p_phone_enabled',
  'p_phone_id1',
  'p_phone_type1',
  'p_phone_number1',
  'p_phone_enabled1',
  'p_employment_status',
  'p_comments',
  ...ATTACHMENT_FIELDS,
  ],
  {
    p_first_name: 'John',
    p_effective_date: '20260823',
    p_file_name1: 'update-proof.pdf',
    p_attachment1: 'dGVzdCBhdHRhY2htZW50',
  },
);

export class DeleteDependentRequestDto {
  @RequiredString('4668195')
  p_dependent_id!: string;

  [key: string]: unknown;
}

defineOptionalStringFields(
  DeleteDependentRequestDto,
  [
    'p_relation_ship_end_date',
    'p_relationship_end_date',
    'p_contact_type',
    'p_relation_ship',
    'p_relationship',
    ...ATTACHMENT_FIELDS,
  ],
  { p_relationship_end_date: '20260823' },
);

export class PassportApplyRequestDto {
  @RequiredString('A498989')
  p_passport_number!: string;

  @RequiredString('20260121')
  p_date_of_issue!: string;

  @RequiredString('20360121')
  p_date_of_expiry!: string;

  @RequiredString('Normal')
  p_type_of_passport!: string;

  @RequiredString('Doha')
  p_place_of_issue!: string;

  @RequiredString('QA')
  p_country_of_issue!: string;

  [key: string]: unknown;
}

defineOptionalStringFields(PassportApplyRequestDto, ATTACHMENT_FIELDS);
