import { Module } from '@nestjs/common';
import { HttpModule } from '@nestjs/axios';
import { ConfigService } from '@nestjs/config';
import { AuthController } from './interface/auth.controller';
import { HealthCheckController } from './interface/healthcheck.controller';
import { AuthService } from './application/auth.service';
import { OnboardingService } from './application/onboarding.service';
import { MpinService } from './application/mpin.service';
import { HealthCheckService } from './application/healthcheck.service';
import { LDAP_USER_PORT, LdapUserPort } from './domain/ports/ldap-user.port';
import { OTP_PORT } from './domain/ports/otp.port';
import { OTP_DELIVERY_PORT } from './domain/ports/otp-delivery.port';
import { MPIN_STORE_PORT } from './domain/ports/mpin-store.port';
import { DEVICE_REGISTRY_PORT } from './domain/ports/device-registry.port';
import { FUNCTION_ACCESS_PORT } from './domain/ports/function-access.port';
import { LdapUserRepository } from './infrastructure/adapters/ldap-user.repository';
import { EntraGraphUserRepository } from './infrastructure/adapters/entra-graph-user.repository';
import { MssqlOtpRepository } from './infrastructure/adapters/mssql-otp.repository';
import { MssqlMpinStoreRepository } from './infrastructure/adapters/mssql-mpin-store.repository';
import { MssqlDeviceRegistryRepository } from './infrastructure/adapters/mssql-device-registry.repository';
import { SmsOtpDeliveryAdapter } from './infrastructure/adapters/sms-otp-delivery.adapter';
import { FunctionAccessStubRepository } from './infrastructure/adapters/function-access.stub.repository';

/**
 * Auth feature module — Sanaad User Authentication & Access Control framework
 * (APIs 1-7). JWT signing/verification comes from the global core AuthModule.
 *
 * OTP / MPIN / device-registry are backed by the legacy Sanaad SQL Server
 * tables (HMC_RHAP_OTP_tbl, HMC_Sanad_DeviceRegn_tbl) via the global
 * MssqlService pool; OTP delivery goes out through the config-driven SMS
 * gateway adapter. Function-access remains a stub (spec pending); non-prod
 * still uses the dev bypass inside each application service.
 *
 * The corporate-directory port (LDAP_USER_PORT) is bound at runtime by
 * AUTH_DIRECTORY: `entra` → Microsoft Graph (EntraGraphUserRepository), else
 * LDAPS (LdapUserRepository, the default/fallback). HttpModule backs the Graph
 * and SMS adapters' outbound calls.
 */
@Module({
  imports: [HttpModule],
  controllers: [AuthController, HealthCheckController],
  providers: [
    AuthService,
    OnboardingService,
    MpinService,
    HealthCheckService,
    LdapUserRepository,
    EntraGraphUserRepository,
    {
      provide: LDAP_USER_PORT,
      inject: [ConfigService, LdapUserRepository, EntraGraphUserRepository],
      useFactory: (
        config: ConfigService,
        ldap: LdapUserRepository,
        entra: EntraGraphUserRepository,
      ): LdapUserPort => (config.get('app.directory') === 'entra' ? entra : ldap),
    },
    { provide: OTP_DELIVERY_PORT, useClass: SmsOtpDeliveryAdapter },
    { provide: OTP_PORT, useClass: MssqlOtpRepository },
    { provide: MPIN_STORE_PORT, useClass: MssqlMpinStoreRepository },
    { provide: DEVICE_REGISTRY_PORT, useClass: MssqlDeviceRegistryRepository },
    { provide: FUNCTION_ACCESS_PORT, useClass: FunctionAccessStubRepository },
  ],
})
export class AuthModule {}
